/* eslint-disable */
// this is an auto generated file. This will be overwritten

export const syncParticipantes = /* GraphQL */ `
  query SyncParticipantes(
    $filter: ModelParticipanteFilterInput
    $limit: Int
    $nextToken: String
    $lastSync: AWSTimestamp
  ) {
    syncParticipantes(
      filter: $filter
      limit: $limit
      nextToken: $nextToken
      lastSync: $lastSync
    ) {
      items {
        id
        nome
        telefone
        genero
        escolaridade
        estuda_ufrj
        curso
        universidade
        periodo
        cidade
        estado
        _version
        _deleted
        _lastChangedAt
        createdAt
        updatedAt
      }
      nextToken
      startedAt
    }
  }
`;
export const getParticipante = /* GraphQL */ `
  query GetParticipante($id: ID!) {
    getParticipante(id: $id) {
      id
      nome
      telefone
      genero
      escolaridade
      estuda_ufrj
      curso
      universidade
      periodo
      participando_id {
        nextToken
        startedAt
      }
      cidade
      estado
      _version
      _deleted
      _lastChangedAt
      createdAt
      updatedAt
    }
  }
`;
export const listParticipantes = /* GraphQL */ `
  query ListParticipantes(
    $filter: ModelParticipanteFilterInput
    $limit: Int
    $nextToken: String
  ) {
    listParticipantes(filter: $filter, limit: $limit, nextToken: $nextToken) {
      items {
        id
        nome
        telefone
        genero
        escolaridade
        estuda_ufrj
        curso
        universidade
        periodo
        cidade
        estado
        _version
        _deleted
        _lastChangedAt
        createdAt
        updatedAt
      }
      nextToken
      startedAt
    }
  }
`;
export const syncParticipandos = /* GraphQL */ `
  query SyncParticipandos(
    $filter: ModelParticipandoFilterInput
    $limit: Int
    $nextToken: String
    $lastSync: AWSTimestamp
  ) {
    syncParticipandos(
      filter: $filter
      limit: $limit
      nextToken: $nextToken
      lastSync: $lastSync
    ) {
      items {
        id
        _version
        _deleted
        _lastChangedAt
        createdAt
        updatedAt
      }
      nextToken
      startedAt
    }
  }
`;
export const getParticipando = /* GraphQL */ `
  query GetParticipando($id: ID!) {
    getParticipando(id: $id) {
      id
      participante_id {
        id
        nome
        telefone
        genero
        escolaridade
        estuda_ufrj
        curso
        universidade
        periodo
        cidade
        estado
        _version
        _deleted
        _lastChangedAt
        createdAt
        updatedAt
      }
      evento_id {
        id
        nome_evento
        nome_palestrante
        descricao
        link_transmissao
        data_inicio
        hora_inicio
        hora_fim
        img
        repositorio
        em_exibicao
        _version
        _deleted
        _lastChangedAt
        createdAt
        updatedAt
      }
      _version
      _deleted
      _lastChangedAt
      createdAt
      updatedAt
    }
  }
`;
export const listParticipandos = /* GraphQL */ `
  query ListParticipandos(
    $filter: ModelParticipandoFilterInput
    $limit: Int
    $nextToken: String
  ) {
    listParticipandos(filter: $filter, limit: $limit, nextToken: $nextToken) {
      items {
        id
        _version
        _deleted
        _lastChangedAt
        createdAt
        updatedAt
      }
      nextToken
      startedAt
    }
  }
`;
export const syncCertificados = /* GraphQL */ `
  query SyncCertificados(
    $filter: ModelCertificadoFilterInput
    $limit: Int
    $nextToken: String
    $lastSync: AWSTimestamp
  ) {
    syncCertificados(
      filter: $filter
      limit: $limit
      nextToken: $nextToken
      lastSync: $lastSync
    ) {
      items {
        id
        _version
        _deleted
        _lastChangedAt
        createdAt
        updatedAt
      }
      nextToken
      startedAt
    }
  }
`;
export const getCertificado = /* GraphQL */ `
  query GetCertificado($id: ID!) {
    getCertificado(id: $id) {
      id
      participante_id {
        id
        nome
        telefone
        genero
        escolaridade
        estuda_ufrj
        curso
        universidade
        periodo
        cidade
        estado
        _version
        _deleted
        _lastChangedAt
        createdAt
        updatedAt
      }
      evento_id {
        id
        nome_evento
        nome_palestrante
        descricao
        link_transmissao
        data_inicio
        hora_inicio
        hora_fim
        img
        repositorio
        em_exibicao
        _version
        _deleted
        _lastChangedAt
        createdAt
        updatedAt
      }
      _version
      _deleted
      _lastChangedAt
      createdAt
      updatedAt
    }
  }
`;
export const listCertificados = /* GraphQL */ `
  query ListCertificados(
    $filter: ModelCertificadoFilterInput
    $limit: Int
    $nextToken: String
  ) {
    listCertificados(filter: $filter, limit: $limit, nextToken: $nextToken) {
      items {
        id
        _version
        _deleted
        _lastChangedAt
        createdAt
        updatedAt
      }
      nextToken
      startedAt
    }
  }
`;
export const syncEventos = /* GraphQL */ `
  query SyncEventos(
    $filter: ModelEventoFilterInput
    $limit: Int
    $nextToken: String
    $lastSync: AWSTimestamp
  ) {
    syncEventos(
      filter: $filter
      limit: $limit
      nextToken: $nextToken
      lastSync: $lastSync
    ) {
      items {
        id
        nome_evento
        nome_palestrante
        descricao
        link_transmissao
        data_inicio
        hora_inicio
        hora_fim
        img
        repositorio
        em_exibicao
        _version
        _deleted
        _lastChangedAt
        createdAt
        updatedAt
      }
      nextToken
      startedAt
    }
  }
`;
export const getEvento = /* GraphQL */ `
  query GetEvento($id: ID!) {
    getEvento(id: $id) {
      id
      nome_evento
      nome_palestrante
      descricao
      link_transmissao
      data_inicio
      hora_inicio
      hora_fim
      img
      repositorio
      em_exibicao
      _version
      _deleted
      _lastChangedAt
      createdAt
      updatedAt
    }
  }
`;
export const listEventos = /* GraphQL */ `
  query ListEventos(
    $filter: ModelEventoFilterInput
    $limit: Int
    $nextToken: String
  ) {
    listEventos(filter: $filter, limit: $limit, nextToken: $nextToken) {
      items {
        id
        nome_evento
        nome_palestrante
        descricao
        link_transmissao
        data_inicio
        hora_inicio
        hora_fim
        img
        repositorio
        em_exibicao
        _version
        _deleted
        _lastChangedAt
        createdAt
        updatedAt
      }
      nextToken
      startedAt
    }
  }
`;
