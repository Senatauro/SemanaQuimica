/* eslint-disable */
// this is an auto generated file. This will be overwritten

export const onCreateParticipante = /* GraphQL */ `
  subscription OnCreateParticipante {
    onCreateParticipante {
      id
      nome
      telefone
      genero
      escolaridade
      estuda_ufrj
      curso
      universidade
      periodo
      participando_id {
        nextToken
        startedAt
      }
      cidade
      estado
      _version
      _deleted
      _lastChangedAt
      createdAt
      updatedAt
    }
  }
`;
export const onUpdateParticipante = /* GraphQL */ `
  subscription OnUpdateParticipante {
    onUpdateParticipante {
      id
      nome
      telefone
      genero
      escolaridade
      estuda_ufrj
      curso
      universidade
      periodo
      participando_id {
        nextToken
        startedAt
      }
      cidade
      estado
      _version
      _deleted
      _lastChangedAt
      createdAt
      updatedAt
    }
  }
`;
export const onDeleteParticipante = /* GraphQL */ `
  subscription OnDeleteParticipante {
    onDeleteParticipante {
      id
      nome
      telefone
      genero
      escolaridade
      estuda_ufrj
      curso
      universidade
      periodo
      participando_id {
        nextToken
        startedAt
      }
      cidade
      estado
      _version
      _deleted
      _lastChangedAt
      createdAt
      updatedAt
    }
  }
`;
export const onCreateParticipando = /* GraphQL */ `
  subscription OnCreateParticipando {
    onCreateParticipando {
      id
      participante_id {
        id
        nome
        telefone
        genero
        escolaridade
        estuda_ufrj
        curso
        universidade
        periodo
        cidade
        estado
        _version
        _deleted
        _lastChangedAt
        createdAt
        updatedAt
      }
      evento_id {
        id
        nome_evento
        nome_palestrante
        descricao
        link_transmissao
        data_inicio
        hora_inicio
        hora_fim
        img
        repositorio
        em_exibicao
        _version
        _deleted
        _lastChangedAt
        createdAt
        updatedAt
      }
      _version
      _deleted
      _lastChangedAt
      createdAt
      updatedAt
    }
  }
`;
export const onUpdateParticipando = /* GraphQL */ `
  subscription OnUpdateParticipando {
    onUpdateParticipando {
      id
      participante_id {
        id
        nome
        telefone
        genero
        escolaridade
        estuda_ufrj
        curso
        universidade
        periodo
        cidade
        estado
        _version
        _deleted
        _lastChangedAt
        createdAt
        updatedAt
      }
      evento_id {
        id
        nome_evento
        nome_palestrante
        descricao
        link_transmissao
        data_inicio
        hora_inicio
        hora_fim
        img
        repositorio
        em_exibicao
        _version
        _deleted
        _lastChangedAt
        createdAt
        updatedAt
      }
      _version
      _deleted
      _lastChangedAt
      createdAt
      updatedAt
    }
  }
`;
export const onDeleteParticipando = /* GraphQL */ `
  subscription OnDeleteParticipando {
    onDeleteParticipando {
      id
      participante_id {
        id
        nome
        telefone
        genero
        escolaridade
        estuda_ufrj
        curso
        universidade
        periodo
        cidade
        estado
        _version
        _deleted
        _lastChangedAt
        createdAt
        updatedAt
      }
      evento_id {
        id
        nome_evento
        nome_palestrante
        descricao
        link_transmissao
        data_inicio
        hora_inicio
        hora_fim
        img
        repositorio
        em_exibicao
        _version
        _deleted
        _lastChangedAt
        createdAt
        updatedAt
      }
      _version
      _deleted
      _lastChangedAt
      createdAt
      updatedAt
    }
  }
`;
export const onCreateCertificado = /* GraphQL */ `
  subscription OnCreateCertificado {
    onCreateCertificado {
      id
      participante_id {
        id
        nome
        telefone
        genero
        escolaridade
        estuda_ufrj
        curso
        universidade
        periodo
        cidade
        estado
        _version
        _deleted
        _lastChangedAt
        createdAt
        updatedAt
      }
      evento_id {
        id
        nome_evento
        nome_palestrante
        descricao
        link_transmissao
        data_inicio
        hora_inicio
        hora_fim
        img
        repositorio
        em_exibicao
        _version
        _deleted
        _lastChangedAt
        createdAt
        updatedAt
      }
      _version
      _deleted
      _lastChangedAt
      createdAt
      updatedAt
    }
  }
`;
export const onUpdateCertificado = /* GraphQL */ `
  subscription OnUpdateCertificado {
    onUpdateCertificado {
      id
      participante_id {
        id
        nome
        telefone
        genero
        escolaridade
        estuda_ufrj
        curso
        universidade
        periodo
        cidade
        estado
        _version
        _deleted
        _lastChangedAt
        createdAt
        updatedAt
      }
      evento_id {
        id
        nome_evento
        nome_palestrante
        descricao
        link_transmissao
        data_inicio
        hora_inicio
        hora_fim
        img
        repositorio
        em_exibicao
        _version
        _deleted
        _lastChangedAt
        createdAt
        updatedAt
      }
      _version
      _deleted
      _lastChangedAt
      createdAt
      updatedAt
    }
  }
`;
export const onDeleteCertificado = /* GraphQL */ `
  subscription OnDeleteCertificado {
    onDeleteCertificado {
      id
      participante_id {
        id
        nome
        telefone
        genero
        escolaridade
        estuda_ufrj
        curso
        universidade
        periodo
        cidade
        estado
        _version
        _deleted
        _lastChangedAt
        createdAt
        updatedAt
      }
      evento_id {
        id
        nome_evento
        nome_palestrante
        descricao
        link_transmissao
        data_inicio
        hora_inicio
        hora_fim
        img
        repositorio
        em_exibicao
        _version
        _deleted
        _lastChangedAt
        createdAt
        updatedAt
      }
      _version
      _deleted
      _lastChangedAt
      createdAt
      updatedAt
    }
  }
`;
export const onCreateEvento = /* GraphQL */ `
  subscription OnCreateEvento {
    onCreateEvento {
      id
      nome_evento
      nome_palestrante
      descricao
      link_transmissao
      data_inicio
      hora_inicio
      hora_fim
      img
      repositorio
      em_exibicao
      _version
      _deleted
      _lastChangedAt
      createdAt
      updatedAt
    }
  }
`;
export const onUpdateEvento = /* GraphQL */ `
  subscription OnUpdateEvento {
    onUpdateEvento {
      id
      nome_evento
      nome_palestrante
      descricao
      link_transmissao
      data_inicio
      hora_inicio
      hora_fim
      img
      repositorio
      em_exibicao
      _version
      _deleted
      _lastChangedAt
      createdAt
      updatedAt
    }
  }
`;
export const onDeleteEvento = /* GraphQL */ `
  subscription OnDeleteEvento {
    onDeleteEvento {
      id
      nome_evento
      nome_palestrante
      descricao
      link_transmissao
      data_inicio
      hora_inicio
      hora_fim
      img
      repositorio
      em_exibicao
      _version
      _deleted
      _lastChangedAt
      createdAt
      updatedAt
    }
  }
`;
