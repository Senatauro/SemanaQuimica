/* eslint-disable */
// this is an auto generated file. This will be overwritten

export const enviarEmail = /* GraphQL */ `
  mutation EnviarEmail($input: enviarEmailInput!) {
    enviarEmail(input: $input) {
      enviado
    }
  }
`;
export const createParticipante = /* GraphQL */ `
  mutation CreateParticipante(
    $input: CreateParticipanteInput!
    $condition: ModelParticipanteConditionInput
  ) {
    createParticipante(input: $input, condition: $condition) {
      id
      nome
      telefone
      genero
      escolaridade
      estuda_ufrj
      curso
      universidade
      periodo
      participando_id {
        nextToken
        startedAt
      }
      cidade
      estado
      _version
      _deleted
      _lastChangedAt
      createdAt
      updatedAt
    }
  }
`;
export const updateParticipante = /* GraphQL */ `
  mutation UpdateParticipante(
    $input: UpdateParticipanteInput!
    $condition: ModelParticipanteConditionInput
  ) {
    updateParticipante(input: $input, condition: $condition) {
      id
      nome
      telefone
      genero
      escolaridade
      estuda_ufrj
      curso
      universidade
      periodo
      participando_id {
        nextToken
        startedAt
      }
      cidade
      estado
      _version
      _deleted
      _lastChangedAt
      createdAt
      updatedAt
    }
  }
`;
export const deleteParticipante = /* GraphQL */ `
  mutation DeleteParticipante(
    $input: DeleteParticipanteInput!
    $condition: ModelParticipanteConditionInput
  ) {
    deleteParticipante(input: $input, condition: $condition) {
      id
      nome
      telefone
      genero
      escolaridade
      estuda_ufrj
      curso
      universidade
      periodo
      participando_id {
        nextToken
        startedAt
      }
      cidade
      estado
      _version
      _deleted
      _lastChangedAt
      createdAt
      updatedAt
    }
  }
`;
export const createParticipando = /* GraphQL */ `
  mutation CreateParticipando(
    $input: CreateParticipandoInput!
    $condition: ModelParticipandoConditionInput
  ) {
    createParticipando(input: $input, condition: $condition) {
      id
      participante_id {
        id
        nome
        telefone
        genero
        escolaridade
        estuda_ufrj
        curso
        universidade
        periodo
        cidade
        estado
        _version
        _deleted
        _lastChangedAt
        createdAt
        updatedAt
      }
      evento_id {
        id
        nome_evento
        nome_palestrante
        descricao
        link_transmissao
        data_inicio
        hora_inicio
        hora_fim
        img
        repositorio
        em_exibicao
        _version
        _deleted
        _lastChangedAt
        createdAt
        updatedAt
      }
      _version
      _deleted
      _lastChangedAt
      createdAt
      updatedAt
    }
  }
`;
export const updateParticipando = /* GraphQL */ `
  mutation UpdateParticipando(
    $input: UpdateParticipandoInput!
    $condition: ModelParticipandoConditionInput
  ) {
    updateParticipando(input: $input, condition: $condition) {
      id
      participante_id {
        id
        nome
        telefone
        genero
        escolaridade
        estuda_ufrj
        curso
        universidade
        periodo
        cidade
        estado
        _version
        _deleted
        _lastChangedAt
        createdAt
        updatedAt
      }
      evento_id {
        id
        nome_evento
        nome_palestrante
        descricao
        link_transmissao
        data_inicio
        hora_inicio
        hora_fim
        img
        repositorio
        em_exibicao
        _version
        _deleted
        _lastChangedAt
        createdAt
        updatedAt
      }
      _version
      _deleted
      _lastChangedAt
      createdAt
      updatedAt
    }
  }
`;
export const deleteParticipando = /* GraphQL */ `
  mutation DeleteParticipando(
    $input: DeleteParticipandoInput!
    $condition: ModelParticipandoConditionInput
  ) {
    deleteParticipando(input: $input, condition: $condition) {
      id
      participante_id {
        id
        nome
        telefone
        genero
        escolaridade
        estuda_ufrj
        curso
        universidade
        periodo
        cidade
        estado
        _version
        _deleted
        _lastChangedAt
        createdAt
        updatedAt
      }
      evento_id {
        id
        nome_evento
        nome_palestrante
        descricao
        link_transmissao
        data_inicio
        hora_inicio
        hora_fim
        img
        repositorio
        em_exibicao
        _version
        _deleted
        _lastChangedAt
        createdAt
        updatedAt
      }
      _version
      _deleted
      _lastChangedAt
      createdAt
      updatedAt
    }
  }
`;
export const createCertificado = /* GraphQL */ `
  mutation CreateCertificado(
    $input: CreateCertificadoInput!
    $condition: ModelCertificadoConditionInput
  ) {
    createCertificado(input: $input, condition: $condition) {
      id
      participante_id {
        id
        nome
        telefone
        genero
        escolaridade
        estuda_ufrj
        curso
        universidade
        periodo
        cidade
        estado
        _version
        _deleted
        _lastChangedAt
        createdAt
        updatedAt
      }
      evento_id {
        id
        nome_evento
        nome_palestrante
        descricao
        link_transmissao
        data_inicio
        hora_inicio
        hora_fim
        img
        repositorio
        em_exibicao
        _version
        _deleted
        _lastChangedAt
        createdAt
        updatedAt
      }
      _version
      _deleted
      _lastChangedAt
      createdAt
      updatedAt
    }
  }
`;
export const updateCertificado = /* GraphQL */ `
  mutation UpdateCertificado(
    $input: UpdateCertificadoInput!
    $condition: ModelCertificadoConditionInput
  ) {
    updateCertificado(input: $input, condition: $condition) {
      id
      participante_id {
        id
        nome
        telefone
        genero
        escolaridade
        estuda_ufrj
        curso
        universidade
        periodo
        cidade
        estado
        _version
        _deleted
        _lastChangedAt
        createdAt
        updatedAt
      }
      evento_id {
        id
        nome_evento
        nome_palestrante
        descricao
        link_transmissao
        data_inicio
        hora_inicio
        hora_fim
        img
        repositorio
        em_exibicao
        _version
        _deleted
        _lastChangedAt
        createdAt
        updatedAt
      }
      _version
      _deleted
      _lastChangedAt
      createdAt
      updatedAt
    }
  }
`;
export const deleteCertificado = /* GraphQL */ `
  mutation DeleteCertificado(
    $input: DeleteCertificadoInput!
    $condition: ModelCertificadoConditionInput
  ) {
    deleteCertificado(input: $input, condition: $condition) {
      id
      participante_id {
        id
        nome
        telefone
        genero
        escolaridade
        estuda_ufrj
        curso
        universidade
        periodo
        cidade
        estado
        _version
        _deleted
        _lastChangedAt
        createdAt
        updatedAt
      }
      evento_id {
        id
        nome_evento
        nome_palestrante
        descricao
        link_transmissao
        data_inicio
        hora_inicio
        hora_fim
        img
        repositorio
        em_exibicao
        _version
        _deleted
        _lastChangedAt
        createdAt
        updatedAt
      }
      _version
      _deleted
      _lastChangedAt
      createdAt
      updatedAt
    }
  }
`;
export const createEvento = /* GraphQL */ `
  mutation CreateEvento(
    $input: CreateEventoInput!
    $condition: ModelEventoConditionInput
  ) {
    createEvento(input: $input, condition: $condition) {
      id
      nome_evento
      nome_palestrante
      descricao
      link_transmissao
      data_inicio
      hora_inicio
      hora_fim
      img
      repositorio
      em_exibicao
      _version
      _deleted
      _lastChangedAt
      createdAt
      updatedAt
    }
  }
`;
export const updateEvento = /* GraphQL */ `
  mutation UpdateEvento(
    $input: UpdateEventoInput!
    $condition: ModelEventoConditionInput
  ) {
    updateEvento(input: $input, condition: $condition) {
      id
      nome_evento
      nome_palestrante
      descricao
      link_transmissao
      data_inicio
      hora_inicio
      hora_fim
      img
      repositorio
      em_exibicao
      _version
      _deleted
      _lastChangedAt
      createdAt
      updatedAt
    }
  }
`;
export const deleteEvento = /* GraphQL */ `
  mutation DeleteEvento(
    $input: DeleteEventoInput!
    $condition: ModelEventoConditionInput
  ) {
    deleteEvento(input: $input, condition: $condition) {
      id
      nome_evento
      nome_palestrante
      descricao
      link_transmissao
      data_inicio
      hora_inicio
      hora_fim
      img
      repositorio
      em_exibicao
      _version
      _deleted
      _lastChangedAt
      createdAt
      updatedAt
    }
  }
`;
